import { AreaTable } from "../../components";

const Reports = () => {
  return (
    <div className="content-area">
     
      <AreaTable />
    </div>
  );
};

export default Reports;
